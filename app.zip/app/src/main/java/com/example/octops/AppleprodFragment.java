package com.example.octops;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.octops.databinding.FragmentAppleprodBinding;
import com.example.octops.databinding.FragmentDashboardBinding;
import com.example.octops.ui.dashboard.DashboardViewModel;

public class AppleprodFragment extends Fragment {



    private FragmentAppleprodBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentAppleprodBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        binding.buttonDeseos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main);
                navController.navigateUp();
                navController.navigate(R.id.navDeseos);
            }
        });

        binding.buttonIrprod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main);
                navController.navigateUp();
                navController.navigate(R.id.navProducto);
            }
        });


        return root;
    }


}