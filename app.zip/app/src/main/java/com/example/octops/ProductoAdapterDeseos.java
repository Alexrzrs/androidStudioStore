package com.example.octops;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProductoAdapterDeseos extends BaseAdapter {

    private Context contexto;
    private JSONArray productos;
    private LayoutInflater inflater;
    private RequestQueue conexion;
    private StringRequest peticion;
    private SharedPreferences sharedPreferences;

    public ProductoAdapterDeseos(Context context, JSONArray productos){
        this.contexto = context;
        this.productos = productos;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return productos.length();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Por cada elemento del arreglo JSON mostraremos el layout del itemproductologged
        if(view == null){
            view = inflater.inflate(R.layout.item_productodeseo, null);
        }

        try{
            JSONObject producto = productos.getJSONObject(i);

            TextView nombreProd = view.findViewById(R.id.tv_nombre_prod);
            nombreProd.setText(producto.getString("nombre"));

            TextView precioProd = view.findViewById(R.id.tv_precio_prod);
            precioProd.setText("$"+producto.getString("precio"));

            ImageView imagenProd = view.findViewById(R.id.iv_img1);
            //Buscar la carpeta de las imagenes como returna "urlImagen": "productos/20211128211525131002-Iphone-13-pro-max.jpg" en string solo recortar
            Picasso.get().load("http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/"+
                    producto.getString("urlImagen")).into(imagenProd);

            TextView idProd = view.findViewById(R.id.tv_producto_id);
            idProd.setText(producto.getString("id"));

            Button borraDeseado = view.findViewById(R.id.buttonEliminarDeseo);
            borraDeseado.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    conexion = Volley.newRequestQueue(contexto);

                    sharedPreferences = contexto.getSharedPreferences(
                            "OCTOPS",
                            Context.MODE_PRIVATE
                    );
                    String sesion = sharedPreferences.getString("sesion", null);
                    String email = sharedPreferences.getString("email", null);


                    peticion = new StringRequest(
                            Request.Method.POST,
                            "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/borraDeseo?apiKey=AdhTYjbsd23568dnmbhgewfhds2345",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    try{
                                        JSONObject objResp = new JSONObject(response);

                                        if(objResp.getBoolean("error") == false){
                                            Toast.makeText(contexto, objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                        }else if(objResp.getBoolean("error") == true){
                                            Toast.makeText(contexto, objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                        }
                                    }catch (Exception e){
                                        Log.e("Error lista", e.getMessage());
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.e("Error Volley", error.getMessage());
                                }
                            }
                    ){
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> parametros = new HashMap<>();
                            parametros.put("email", email);
                            parametros.put("sesion", sesion);
                            parametros.put("idProducto", idProd.getText().toString());
                            return parametros;
                        }
                    };
                    conexion.add(peticion);
                }
            });

        }catch(Exception e){
            Log.e("error adapter", e.getMessage());
        }
        return  view;
    }
}
