package com.example.octops;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.databinding.FragmentLoginBinding;
import com.example.octops.databinding.FragmentRegistroBinding;
import com.example.octops.databinding.FragmentSecondBinding;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SecondFragment extends Fragment {

    private FragmentRegistroBinding binding;
    private RequestQueue conexion;
    private StringRequest peticion;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentRegistroBinding.inflate(inflater, container, false);
        conexion = Volley.newRequestQueue(getActivity());
        View root = binding.getRoot();

        binding.buttonRegistrarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String emailreg = binding.eTRegEmail.getText().toString();
                final String nomreg = binding.eTRegNombre.getText().toString();
                final String ap1reg  = binding.eTRegAp1.getText().toString();
                final String ap2reg = binding.eTRegAp2.getText().toString();
                final String passreg = binding.eTRegPass.getText().toString();

                peticion = new StringRequest(
                        Request.Method.POST,
                        "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/insertaCliente?apiKey=AdhTYjbsd23568dnmbhgewfhds2345",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try{
                                    JSONObject objResp = new JSONObject(response);

                                    if(objResp.getBoolean("error") == false){
                                        Toast.makeText(getActivity(), objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();

                                        NavHostFragment.findNavController(
                                                SecondFragment.this
                                        ).navigate(R.id.FirstFragment);

                                    }else if(objResp.getBoolean("error") == true){
                                        Toast.makeText(getActivity(), objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                    }
                                }catch(Exception e){
                                    Log.e("Error no se pudo guardar el registro", e.getMessage());
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.e("Error volley", error.getMessage());
                            }
                        }
                ){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> parametros = new HashMap<>();
                        parametros.put("email", emailreg);
                        parametros.put("nombre", nomreg);
                        parametros.put("apellidoPaterno", ap1reg);
                        parametros.put("apellidoMaterno", ap2reg);
                        parametros.put("password", passreg);
                        return parametros;
                    }
                };
                conexion.add(peticion);




            }
        });

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonCancelarReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}