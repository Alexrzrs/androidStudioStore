package com.example.octops;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.octops.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navHome, R.id.navBuscador, R.id.navDeseos, R.id.navCarrito, R.id.navCuenta)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavController navController = Navigation.findNavController(
                    MainActivity.this,
                    R.id.nav_host_fragment_activity_main
            );
            navController.navigateUp();
            navController.navigate(R.id.navHome);
        }

        return super.onOptionsItemSelected(item);
    }

    /* Al presionar back despues de logearse pregunta si quiere salir */


    @Override
    public void onBackPressed() {
        salir();
    }

    /*Creamos metodo de salir y al aceptar regresa al home */
    public void salir(){
        AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
        alerta.setTitle("¿Cerrar sesión?");
        alerta.setMessage("¿Seguro que deseas salir?");
        alerta.setNegativeButton("No", null);
        alerta.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                finish();
                startActivity(
                        new Intent(
                                MainActivity.this,
                                InicioActivity.class
                        )
                );
            }
        });
        alerta.setIcon(R.drawable.warning);
        alerta.setCancelable(false);
        alerta.show();
    }

    public void verDetalle(View vista){ //Metodo que se usara para onClick en las cardview
        TextView idProductoDet = vista.findViewById(R.id.tv_producto_id);
        Log.d("idProductoDet", idProductoDet.getText().toString());

        NavController navController = Navigation.findNavController(
                MainActivity.this,
                R.id.nav_host_fragment_activity_main
        );
        navController.navigateUp();
        Bundle datos = new Bundle();
        datos.putString("idProd", idProductoDet.getText().toString());

        navController.navigate(R.id.navProducto, datos);
        getSupportActionBar().setTitle("Detalle del producto");
    }
}