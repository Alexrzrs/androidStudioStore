package com.example.octops;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.octops.databinding.FragmentHistorialcomprasBinding;
import com.example.octops.databinding.FragmentPagadoBinding;

public class HistorialcomprasFragment extends Fragment {

    private FragmentHistorialcomprasBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHistorialcomprasBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        binding.buttonVerPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main);
                navController.navigateUp();
                navController.navigate(R.id.navFactura);
            }
        });


        return root;
    }

}