package com.example.octops.ui.home;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.MainActivity;
import com.example.octops.ProductoAdapter;
import com.example.octops.ProductoAdapterlog;
import com.example.octops.databinding.FragmentFirstBinding;
import com.example.octops.databinding.FragmentHomeBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private ProgressDialog progress;
    private SharedPreferences sharedPreferences;
    private RequestQueue conexion;
    private StringRequest peticion;

    ProductoAdapterlog adaptador;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        progress = new ProgressDialog(getActivity());
        progress.setTitle("Iniciando aplicacion");
        progress.setMessage("Por favor espere un momento...");
        progress.setIndeterminate(true);
        progress.setCancelable(false);
        progress.show();

        sharedPreferences = getActivity().getSharedPreferences(
                "OCTOPS",
                Context.MODE_PRIVATE
        );
        //Verificar si hay valores en el espacio de trabajo
        String idSp = sharedPreferences.getString("id", null);
        String userPassSp = sharedPreferences.getString("user_pass", null);

        //Verificar si hubo inicio de sesion, los valores no tendran que ser nulos
        if (idSp != null && userPassSp != null) {
            startActivity(
                    new Intent(
                            getActivity(),
                            MainActivity.class
                    )
            );
        } else {
            progress.hide();
        }

        binding.prodsenhome.post(new Runnable() {
            @Override
            public void run() {
                binding.prodsenhome.setRefreshing(true);
                datosProductos();
            }
        });

        binding.prodsenhome.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                datosProductos();
            }
        });

        conexion = Volley.newRequestQueue(getActivity());
        return root;
    }

    public void datosProductos() {
        final String apiKey = "AdhTYjbsd23568dnmbhgewfhds2345";

        peticion = new StringRequest(
                Request.Method.GET,
                "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/obtenProductos?apiKey=" + apiKey,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Serv prod", response);

                        try {
                            //creamos objeto JSON de la repsuesta
                            JSONObject objRes = new JSONObject(response);

                            //Verificamos que no haya error en el web service
                            if (objRes.getBoolean("error") == false) {
                                JSONArray productos = objRes.getJSONArray("productos");

                                //Inicializamos el adaptador
                                adaptador = new ProductoAdapterlog(getActivity(), productos);
                                //Vinculamos el adaptador con el listView
                                binding.produtoslogged.setAdapter(adaptador);
                                //Actualizar el contenido del adaptador
                                adaptador.notifyDataSetChanged();
                                //Quitar loader del swipeRefresh
                                binding.prodsenhome.setRefreshing(false);
                            }


                        } catch (Exception e) {
                            Log.e("Error en el catch", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error volley", error.getMessage());
                    }
                }
        );
        conexion.add(peticion);

    }


}