package com.example.octops.ui.notifications;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.MainActivity;
import com.example.octops.ProductoAdapterDeseos;
import com.example.octops.ProductoAdapterlog;
import com.example.octops.R;
import com.example.octops.databinding.FragmentHomeBinding;
import com.example.octops.databinding.FragmentNotificationsBinding;
import com.example.octops.ui.home.HomeViewModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NotificationsFragment extends Fragment {

    private FragmentNotificationsBinding binding;
    private RequestQueue conexion;
    private StringRequest peticion;
    private SharedPreferences sharedPreferences;

    ProductoAdapterDeseos adaptador;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentNotificationsBinding.inflate(inflater, container, false);

        binding.prodsendeseos.post(new Runnable() {
            @Override
            public void run() {
                binding.prodsendeseos.setRefreshing(true);
                datosProductos();
            }
        });

        binding.prodsendeseos.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                datosProductos();
            }
        });
        conexion = Volley.newRequestQueue(getActivity());

        return binding.getRoot();
    }

    public void datosProductos(){
        final String apiKey = "AdhTYjbsd23568dnmbhgewfhds2345";
        sharedPreferences = getActivity().getSharedPreferences(
                "OCTOPS",
                Context.MODE_PRIVATE
        );
        String sesion = sharedPreferences.getString("sesion", null);
        String email = sharedPreferences.getString("email", null);
        peticion = new StringRequest(
                Request.Method.POST,
                "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/obtenDeseos",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Serv prod", response);
                        try{
                            JSONObject objResp = new JSONObject(response);

                            if(objResp.getBoolean("error") == false){
                                JSONArray deseados = objResp.getJSONArray("deseados");

                                adaptador = new ProductoAdapterDeseos(getActivity(), deseados);
                                binding.productosdeseados.setAdapter(adaptador);
                                adaptador.notifyDataSetChanged();
                                binding.prodsendeseos.setRefreshing(false);
                            }
                        }catch (Exception e){
                            Log.e("Error en el catch", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error volley", error.getMessage());
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("apiKey", apiKey);
                parametros.put("email", email);
                parametros.put("sesion", sesion);
                return parametros;
            }
        };
        conexion.add(peticion);
    }
}