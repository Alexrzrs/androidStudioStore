package com.example.octops;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProductoAdapter extends BaseAdapter {

    private Context contexto;
    private JSONArray productos;
    private LayoutInflater inflater;

    public ProductoAdapter(Context context, JSONArray productos){
        this.contexto = context;
        this.productos = productos;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return productos.length();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //cada elemento del arreglo JSON sera mostrado en el layout de cada producto
        if(view == null){
            view = inflater.inflate(R.layout.item_producto, null);
        }

        try{
            JSONObject producto = productos.getJSONObject(i);

            TextView nombreProd = view.findViewById(R.id.tv_nombre_prod);
            nombreProd.setText(producto.getString("nombre"));

            TextView precioProd = view.findViewById(R.id.tv_precio_prod);
            precioProd.setText("$"+producto.getString("precio"));

            ImageView imagenProd = view.findViewById(R.id.iv_img1);
            //Buscar la carpeta de las imagenes como returna "urlImagen": "productos/20211128211525131002-Iphone-13-pro-max.jpg" en string solo recortar
            Picasso.get().load("http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/"+
                    producto.getString("urlImagen")).into(imagenProd);

            TextView idProd = view.findViewById(R.id.tv_producto_id);
            idProd.setText(producto.getString("id"));

        }catch(Exception e){
            Log.e("error adapter", e.getMessage());
        }
        return  view;
    }
}