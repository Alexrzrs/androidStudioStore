package com.example.octops;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.databinding.FragmentFirstBinding;
import com.example.octops.databinding.FragmentLoginBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginFragment extends Fragment {

    private FragmentLoginBinding binding;

    private RequestQueue conexionServ;
    private StringRequest peticionServ;
    private ProgressDialog progress;
    private AlertDialog.Builder alerta;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor spEditor;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentLoginBinding.inflate(inflater, container, false);

        conexionServ = Volley.newRequestQueue(getActivity());
        progress = new ProgressDialog(getActivity());
        progress.setTitle("Autenticando");
        progress.setMessage("Por favor espere...");
        progress.setCancelable(false);
        progress.setIndeterminate(true);

        alerta = new AlertDialog.Builder(getActivity());
        /*
        Inicializamos el espacio de datos de nuestra app
         */
        sharedPreferences = getActivity().getSharedPreferences(
                "OCTOPS",
                Context.MODE_PRIVATE
        );
        /*
        Inicializamos el editor del espacio de preferencias
         */
        spEditor = sharedPreferences.edit();

        binding.buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = binding.eTLogEmail.getText().toString();
                final String password = binding.eTLogPass.getText().toString();
                progress.show();

                peticionServ = new StringRequest(
                        Request.Method.POST,
                        "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/loginCliente?apiKey=AdhTYjbsd23568dnmbhgewfhds2345",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                progress.hide();

                                //La respuesta se convierte en objeto jason para poder leerla
                                try {
                                    JSONObject objRespuesta = new JSONObject(response);

                                    String error = objRespuesta.getString("error");

                                    //Verifica lo que devuelve el json si es false el error continua si no error de contra o usu
                                    if (error == "false") {

                                        //Tomamos el objeto con los datos del usuario
                                        JSONObject cliente = objRespuesta.getJSONObject("cliente");
                                        String email = cliente.getString("email");
                                        String sesion = cliente.getString("sesion");

                                        /*
                                        Agregamos a SharedPReferences en nuestro espacio
                                        t196 el id y la contraseña encriptada del usuario
                                        El método put me permite agregar valores
                                         */
                                        //Agregar email y key de la sesion
                                        spEditor.putString("email", email);
                                        spEditor.putString("sesion", sesion);

                                        //Guardamos
                                        spEditor.commit();

                                        /* Redirecciona al fragmento home */
                                        startActivity(
                                                new Intent(
                                                        getActivity(),
                                                        MainActivity.class
                                                )
                                        );
                                    }

                                    else if (error == "true") {
                                        alerta = new AlertDialog.Builder(getActivity());
                                        alerta.setTitle("¡Hey!");
                                        alerta.setMessage("Usuario o contraseña incorrectos\nPor favor intenta de nuevo");
                                        alerta.setIcon(R.drawable.warning);
                                        alerta.setPositiveButton("Aceptar", null);
                                        alerta.setCancelable(false);
                                        alerta.show();

                                    }
                                }

                                catch(Exception e) {
                                    Toast.makeText(getActivity(), e.getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progress.hide();
                                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                            }
                        }
                //Variables post
                ){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> parametros = new HashMap<>();

                        //Agregamos los parametros y su valor
                        parametros.put("email", email);
                        parametros.put("password", password);
                        return parametros;
                    }
                };
                conexionServ.add(peticionServ);
            }
        });

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(LoginFragment.this)
                        .navigate(R.id.action_LoginFragment_to_SecondFragment);
            }
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}