package com.example.octops;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.databinding.FragmentFirstBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private ProgressDialog progress;
    private SharedPreferences sharedPreferences;
    private RequestQueue conexion;
    private StringRequest peticion;


    ProductoAdapter adaptador;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        View root =  binding.getRoot();

        progress = new ProgressDialog(getActivity());
        progress.setTitle("Inicializando");
        progress.setMessage("Cargando...");
        progress.setMessage("Cargando...");
        progress.setIndeterminate(true);
        progress.setCancelable(false);
        progress.show();

        sharedPreferences = getActivity().getSharedPreferences(
                "OCTOPS",
                Context.MODE_PRIVATE
        );
        //Verificar si hay valores en el espacio de trabajo
        String idSp = sharedPreferences.getString("id", null);
        String userPassSp = sharedPreferences.getString("user_pass", null);

        //Verificar si hubo inicio de sesion, los valores no tendran que ser nulos
        if(idSp != null && userPassSp != null){
            startActivity(
                    new Intent(
                            getActivity(),
                            MainActivity.class
                    )
            );
        }else{
            progress.hide();
        }

        binding.srllistaunlogged.post(new Runnable() {
            @Override
            public void run() {
                binding.srllistaunlogged.setRefreshing(true);
                datosProductos();
            }
        });

        binding.srllistaunlogged.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                datosProductos();
            }
        });

        conexion = Volley.newRequestQueue(getActivity());
        return root;
    }

    public void datosProductos(){
        final String apiKey = "AdhTYjbsd23568dnmbhgewfhds2345";

        peticion = new StringRequest(
                Request.Method.GET,
                "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/obtenProductos?apiKey="+apiKey,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Serv prod", response);

                        try{
                            //creamos objeto JSON de la repsuesta
                            JSONObject objRes = new JSONObject(response);

                            //Verificamos que no haya error en el web service
                            if(objRes.getBoolean("error") == false){
                                JSONArray productos = objRes.getJSONArray("productos");

                                //Inicializamos el adaptador
                                adaptador = new ProductoAdapter(getActivity(), productos);
                                //Vinculamos el adaptador con el listView
                                binding.Productosunlogged.setAdapter(adaptador);
                                //Actualizar el contenido del adaptador
                                adaptador.notifyDataSetChanged();
                                //Quitar loader del swipeRefresh
                                binding.srllistaunlogged.setRefreshing(false);
                            }


                        }catch(Exception e){
                            Log.e("Error en el catch", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error volley", error.getMessage());
                    }
                }
        );
        conexion.add(peticion);

    }


}