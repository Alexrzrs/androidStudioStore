package com.example.octops;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.octops.databinding.FragmentAppleprodBinding;
import com.example.octops.databinding.FragmentProductosBinding;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProductosFragment extends Fragment {


    private RequestQueue conexion;
    private StringRequest peticion;
    private SharedPreferences sharedPreferences;
    private FragmentProductosBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentProductosBinding.inflate(inflater, container, false);

        Bundle datos = this.getArguments();
        String strIdProducto = datos.getString("idProd", "");
        Log.d("strIdProducto", strIdProducto);

        conexion = Volley.newRequestQueue(getActivity());

        peticion = new StringRequest(
                //&idProducto=3
                Request.Method.POST,
                "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/obtenDetalle?apiKey=AdhTYjbsd23568dnmbhgewfhds2345",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject obtResp = new JSONObject(response);

                            if(obtResp.getBoolean("error") == false){
                                JSONObject producto = obtResp.getJSONObject("productos");

                                Picasso.get().load("http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/"+
                                        producto.getString("urlImagen")).into(binding.detprodimg);
                                binding.nomdetprod.setText(producto.getString("nombre"));
                                binding.detprodprec.setText("$"+producto.getString("precio"));
                                binding.detproddesc.setText(producto.getString("descripcion"));
                                binding.detidprod.setText(producto.getString("id"));
                            }else if(obtResp.getBoolean("error") == true){

                            }
                        }catch (Exception e){
                            Log.e("Error message", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error Volley", error.getMessage());
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("idProducto", strIdProducto);
                return parametros;
            }


        };
        conexion.add(peticion);


        binding.detprodaddcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main);
                navController.navigateUp();
                navController.navigate(R.id.navCarrito);
            }
        });

        binding.detprodaddwish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        conexion = Volley.newRequestQueue(getActivity());

                        sharedPreferences = getActivity().getSharedPreferences(
                                "OCTOPS",
                                Context.MODE_PRIVATE
                        );
                        String sesion = sharedPreferences.getString("sesion", null);
                        String email = sharedPreferences.getString("email", null);


                        peticion = new StringRequest(
                                Request.Method.POST,
                                "http://dtai.uteq.edu.mx/~ruiefr198/awos_t198/codeigniter/index.php/webServices/insertaDeseo?apiKey=AdhTYjbsd23568dnmbhgewfhds2345",
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                        try{
                                            JSONObject objResp = new JSONObject(response);

                                            if(objResp.getBoolean("error") == false){
                                                Toast.makeText(getActivity(), objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                            }else if(objResp.getBoolean("error") == true){
                                                Toast.makeText(getActivity(), objResp.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                            }
                                        }catch (Exception e){
                                            Log.e("Error lista", e.getMessage());
                                        }
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Log.e("Error Volley", error.getMessage());
                                    }
                                }
                        ){
                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> parametros = new HashMap<>();
                                parametros.put("email", email);
                                parametros.put("sesion", sesion);
                                parametros.put("idProducto", strIdProducto);
                                return parametros;
                            }
                        };
                        conexion.add(peticion);
                    }
                });



        return binding.getRoot();
    }
}