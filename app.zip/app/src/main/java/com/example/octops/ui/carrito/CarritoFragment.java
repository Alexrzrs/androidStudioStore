package com.example.octops.ui.carrito;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.octops.R;
import com.example.octops.databinding.FragmentCarritoBinding;
import com.example.octops.databinding.FragmentDashboardBinding;

public class CarritoFragment extends Fragment {

    private CarritoViewModel carritoViewModel;
    private FragmentCarritoBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        carritoViewModel =
                new ViewModelProvider(this).get(CarritoViewModel.class);

        binding = FragmentCarritoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        carritoViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

            }
        });

        binding.buttonPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main);
                navController.navigateUp();
                navController.navigate(R.id.navPagado);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}